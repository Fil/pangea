
function m_otherklocus
 
% Computes the locus of points with area magnification equal to 2/sqrt(3)
% and plots them on a preplotted tetra25eq map

% w1 is a key parameter from Doug McIntyre's Wallpaper Maps paper
w1 = gamma(1/3)*gamma(1/2)/(3*gamma(5/6));
w = sqrt(3)*w1;
wo2 = w/2;
wo4 = w/4;
h = 1.5*w1;
ho2 = h/2;
maxjump = 0.05;
dtr = pi/180;
rtd = 180/pi;

% First plot loci that go from pole to pole

    for j = 1:361
        lat = 0.5*(j - 181);
        s   = sin(dtr*lat);
        c   = -2*s/(sqrt(3)+sqrt(2+s^2));
        lon = 0.5*rtd*acos(c);
        if lon < 0
            lon = lon + 360;
        end
        if lon > 360;
            lon = lon - 360;
        end
        [zmeq(j),zmnp(j),zmsp(j)] = m_tetra1(lon,lat,w1);
        zmeq(722+j) = zmeq(j) - w*sign(real(zmeq(j)) - wo4);
        lon = -lon;
        if lon < 0
            lon = lon + 360;
        end
        if lon > 360;
            lon = lon - 360;
        end
        [zmeq(361+j),zmnp(361+j),zmsp(361+j)] = m_tetra1(lon,lat,w1);
        zmeq(1083+j) = zmeq(361+j) - w*sign(real(zmeq(361+j)) - wo4);
    end
    wm = m_fixjumps(zmeq,maxjump);
    plot(wm,'r--')%,'linewidth',0.1)
    
% Now compute and plot locus near the equator
    
    for j = 1:721
        lon = 0.5*(j-1);
        c   = cos(2*dtr*lon);
        s   = -c/(2*sqrt(3)+sqrt(8+c^2));
        lat = rtd*asin(s);
        [zpeq(j),zpnp(j),zpsp(j)] = m_tetra1(lon,lat,w1);
    end
    wp = m_fixjumps(zpeq,maxjump);
    plot(wp,'r--')
end
        