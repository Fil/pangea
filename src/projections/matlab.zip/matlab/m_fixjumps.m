function zout = m_fixjumps (zin,maxjump)
% Function to check for and fix boundary crossings by inserting NaNs

% input
% zin file of complex numbers to be plotted
% maxjump = length of maximum jump to be plotted

gaps = 0;
left = 1;
for i = 1:length(zin)-1
    if abs(zin(i+1) - zin(i)) > maxjump
        zout(left+gaps:i+gaps) = zin(left:i);
        zout(i+gaps+1) = NaN + 1j*NaN;
        gaps = gaps + 1;
        left = i + 1;
    end
end
zout(left+gaps:i+gaps+1) = zin(left:i+1);
end