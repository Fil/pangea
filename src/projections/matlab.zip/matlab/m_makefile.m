% This program creates a complex file of latitude/longitude points on which
% the area magnification factor of the tetrahedral map projection equals 
% 4/3, 2, or 4. The computation is exact for psi equal to multiples of 
% 60 degrees; an approximate interpolation is used for other values of psi.

% output
% real(kfile(i)) = longitude 
% imag(kfile(i)) = latitude
% kfile(2:1002)    points with s=4/3 for first singularity
% kfile(1004:2004) points with s=2 for first singularity
% kfile(2006:3006) points with s=4 for first singularity
% kfile(3008;4008) points with s=4/3 for second singularity
% kfile(4010:5010) points with s=2 for second singularity
% kfile(5012:6012) points with s=4 for second singularity
% kfile(6014:7014) points with s=4/3 for third singularity
% kfile(7016:8016) points with s=2 for third singularity
% kfile(8018:9018) points with s=4 for third singularity
% kfile(9020:10020) points with s=4/3 for fourth singularity
% kfile(10022:11022) points with s=2 for fourth singularity
% kfile(11024:12024) points with s=4 for fourth singularity
% kfile(1002*n + 1) = NaN + 1j*Nan to signal breaks

rtd = 180/pi;
r2 = sqrt(2);
r3 = sqrt(3);
r3inv = 1/r3;

% create scale factor loci around first singularity
kfile(1)    = NaN + 1j*NaN;
kfile(1003) = NaN + 1j*NaN;
kfile(2005) = NaN + 1j*NaN;
kfile(3007) = NaN + 1j*NaN;
for i=1:1001
    psi   = .002*(i-1)*pi;
    spsi  = sin(psi);
    cpsi  = cos(psi);
    s3psi = sin(3*psi);
    sa    = r3inv - 0.009247198*(s3psi - 1);% s = 4/3, exact for s3psi = 1
    ca    = sqrt(1-sa^2);
    kfile(1+i) = rtd*atan(r3*sa*cpsi/(r2*ca-sa*spsi))... 
          + 1j*(rtd*asin(r3inv*(ca + r2*sa*spsi)));
    sa    = 0.3663 - 0.0009*s3psi;  % s = 2
    ca    = sqrt(1-sa^2);
    kfile(1003+i) = rtd*atan(r3*sa*cpsi/(r2*ca-sa*spsi))... 
          + 1j*(rtd*asin(r3inv*(ca + r2*sa*spsi)));
    sa    = 0.1782;                 % s = 4
    ca    = sqrt(1-sa^2);
    kfile(2005+i) = rtd*atan(r3*sa*cpsi/(r2*ca-sa*spsi))... % s=4
        +1j*(rtd*asin(r3inv*(ca + r2*sa*spsi)));      
end
% second singularity
kfile(3008:6013) = kfile(2:3007) + 180*ones(1,3006);
% third singularity
kfile(6014:9019) = 2*real(kfile(2:3007)) + 90*ones(1,3006) - kfile(2:3007);
% fourth singularity
kfile(9020:12025) = kfile(6014:9019) + 180*ones(1,3006);
% Fix longitudes to be in [0, 360]
for i = 2:12024
    if real(kfile(i)) < 0
        kfile(i) = kfile(i) + 360;
    end
    if real(kfile(i)) > 360
        kfile(i) = kfile(i) - 360;
    end
end