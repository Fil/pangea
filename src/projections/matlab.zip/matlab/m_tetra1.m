function [weq,wnp,wsp] = m_tetra1(lon,lat,w1)
% Transforms one longitude/latitude point into complex numbers 
% weq, wnp, wsp = x + 1j*y according to the tetrahedral projection.

% input
% lon = longitude (degrees) between 0 and 360
% lat = latitude (degrees) between -90 and 90
% w1 = gamma(1/3)*gamma(1/2)/(3*gamma(5/6)); Key parameter from 
%                          Doug McIntyre's Wallpaper Maps paper
% output
% weq = complex point to be plotted for an equatorial map
% wnp = complex point to be plotted for a north polar map
% wsp = complex point to be plotted for a south polar map

% useful parameters
w = sqrt(3)*w1;
wo2 = w/2;
h = 1.5*w1;
ho2 = h/2;

% Find sector, and longitude within sector
if lon < 45
    sector = 1;
    slon = lon;
elseif lon < 135
    sector = 2;
    slon = lon - 90;
elseif lon < 225
    sector = 3;
    slon = lon - 180;
elseif lon < 315
    sector = 4;
    slon = lon - 270;
else
    sector = 5;
    slon = lon - 360;
end

% Convert lat/lon to cartesian r
dtr = pi/180;
r = [cos(dtr*lat)*cos(dtr*slon); cos(dtr*lat)*sin(dtr*slon); sin(dtr*lat)];

% Rotate about the y axis so that the face center on this sector will be at 
% the north pole
cgam = sqrt(1/3);
sgam = sqrt(2/3);
sig = sign((-1)^sector);
rr = [sig*cgam 0 -sgam; 0 1 0; sgam 0 sig*cgam]*r;

% Now the stereographic projection from the south pole, scaled and rotated
% so that the singular point on this sector ends up at z = 1
z = sig*sqrt(2)*(rr(1) + 1j*rr(2))/(1 + rr(3));

% Now the elliptic integral. G is from Mcintyre.
G = [-2.21759648442110e-7; -3.57526015225576e-7; -3.82869799649063e-7; ...
      1.92759601701790e-8;  1.44135001041810e-6;  4.70614523937179e-6; ...
      1.03865580818367e-5;  1.73095888028726e-5;  1.91691805888369e-5; ...
     -1.59257630018706e-6; -8.21205120500051e-5; -2.84084537293856e-4; ...
     -6.75190201960282e-4; -1.23044177962310e-3; -1.50351632601465e-3; ...
      3.34114739114366e-4;  0.010309826235529  ;  0.0481125224324687 ; ...
      0.192450089729875  ;  1.154700538379252  ];
temp = sqrt(1-z)*polyval(G,(1-z)) - ho2;

% Plot file for the equatorial map
if abs(imag(temp)) <= wo2
    weq = sig*1j*temp + (sector - 3)*wo2;
else
    weq = NaN + 1j*NaN; % eliminate outliers across longitudes 90, 180, 270
end
if abs(real(weq)) > w
    weq =  NaN + 1j*NaN; % eliminate outliers beyond longitude 0 or 360
end
if real(weq) < -3*w/4 
    weq = weq + 2*w;
end

% Plot file for the north polar map
if lon <= 180
    wnp =  1j*(weq + wo2) + ho2;
else
    wnp = -1j*(weq - wo2) - ho2;
end
if imag(wnp) > wo2
    wnp =  wnp - 1j*2*w;  
end
if abs(real(wnp)) > h | abs(imag(wnp)) > wo2
    wnp = NaN + 1j*NaN;
end

% Plot file for the south polar map
if lon < 90
    wsp = -1j*(weq + w) + ho2;
elseif lon > 270
    wsp = -1j*(weq - w) + ho2;
else
    wsp = 1j*weq - ho2;
end
if imag(wsp) < -wo2
    wsp =  wsp + 1j*2*w; 
end
if abs(real(wsp)) > h | abs(imag(wsp)) > wo2
    wsp = NaN + 1j*NaN;
end
end
        