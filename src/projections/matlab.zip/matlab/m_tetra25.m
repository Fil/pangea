
function m_tetra25(ncst,kfile,mtype,kplot)
% Computes and plots tetrahedral projections of the full globe with
%          one singularity at 35.26439 deg North, 25 deg West.
% Parallels and meridians at 10 deg intervals

% input
% ncst file of coastline points
% ncst(:,1) coastline longitudes (degrees), |ncst(:,1)| ? 180
% ncst(:,2) coastline latitudes (degrees),  |ncst(:,2)| < 90
% ncst(:,1)=ncst(:,2)=NaN marks the breaks between coastline segments
% kfile = file of equal k loci created by m_makefile, same format as ncst
% mtype = 1 plots an equatorial map
% mtype = 2 plots a map centered on the south pole
% mtype = 3 plots a map centered on the north pole
% mtype = 4, 5, 6, 7 plot partially overlapping north and south pole maps
% mtype = 8 plots wallpaper map
% kplot = flag to plot loci of points with with k = k_min*4, k = k_min*2,
%         and k = k_min*2/sqrt(3) [incomplete for mtype = 8]
% kplot = 0, don't plot; kplot ~= 0 do plot (except for mtype = 8)

% w1 is a key parameter from Doug McIntyre's Wallpaper Maps paper
w1  = gamma(1/3)*gamma(1/2)/(3*gamma(5/6));
w   = sqrt(3)*w1;
wo2 = w/2;
wo4 = w/4;
h   = 1.5*w1;
ho2 = h/2;
maxjump = 0.05;
cent = -25; % longitude of one northern singularity in degrees
off  = ho2+1j*wo4; % offsets for double maps os(mtype)
os   = [1j*1e-10 1j*1e-10 1j*1e-10 off -conj(off) -off conj(off) off];
os8  = ho2 - 3*wo4*1j;
os9  = -3*ho2 - 3*wo4*1j;
os10 = ho2 + 5*wo4*1j;
lpts = 321*ones(36,1); % lengths of meridian lines
for k = 1:4
    lpts(9*k- 4) = 361;
end
% Plot meridians and parallels at 10 degree intervals
clf
axis off
axis equal
hold on
for i = 1:36 % Compute and plot meridians first
    lon    = 10*i - 5;
    for j = 1:lpts(i)
        lat = 0.5*j-0.25*(lpts(i)+1);
        [zmeq(j),zmnp(j),zmsp(j)] = m_tetra1(lon,lat,w1);
        wmeq = m_fixjumps(zmeq,maxjump);
        wmsp = m_fixjumps(zmsp,maxjump);
        wmnp = m_fixjumps(zmnp,maxjump);
    end
    if mtype == 1;
        plot(wmeq,'c')%,'linewidth',0.1)
    end
    if mtype == 2 | mtype > 3
        plot(wmsp+os(mtype)*ones(1,length(wmsp)),'c'   )
    end     
    if mtype >= 3
        plot(wmnp-os(mtype)*ones(1,length(wmnp)),'c'  )
    end    
    if mtype == 8
        plot(wmnp-os8*ones(1,length(wmnp)),'c'  )
        plot(wmsp+os8*ones(1,length(wmsp)),'c'  )
        if i < 10
            plot(wmsp+os9*ones(1,length(wmsp)),'c'  )
            plot(wmsp+os10*ones(1,length(wmsp)),'c'  )
        end
    end
end
for i = 1:17 % % Now compute and plot parallels
    lat = 10*i - 90;
    for j = 1:723
        lon = 0.5*(j-2);
        [zpeq(j),zpnp(j),zpsp(j)] = m_tetra1(lon,lat,w1);
    end
    % Remove jumps across boundaries and plot
    if mtype == 1
        wp = m_fixjumps(zpeq,maxjump);
        plot(wp,'c')
    end
    if mtype == 2 | mtype > 3
        wp = (-1)^mtype*m_fixjumps(zpnp,maxjump);
        plot(wp+os(mtype)*ones(1,length(wp)),'c'  )
    end     
    if mtype == 3
        wp = m_fixjumps(zpsp,maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
    end     
    if mtype == 4 | mtype == 8
        wp = m_fixjumps(zpsp(1:541),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c'  )
    end    
    if mtype == 5
        wp = m_fixjumps(zpsp(1:361),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
        wp = m_fixjumps(zpsp(541:721),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
    end     
    if mtype == 6
        wp = m_fixjumps(zpsp(1:181),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
        wp = m_fixjumps(zpsp(361:721),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
    end    
    if mtype == 7
        wp = m_fixjumps(zpsp(181:721),maxjump);
        plot(wp-os(mtype)*ones(1,length(wp)),'c' )
    end     
    if mtype == 8
        wp = m_fixjumps(zpnp(181:721),maxjump);
        plot(wp-os8*ones(1,length(wp)),'c'  )
        wp = m_fixjumps(zpsp(1:361),maxjump);
        plot(wp+os8*ones(1,length(wp)),'c'  )
        wp = m_fixjumps(zpsp(541:721),maxjump);
        plot(wp+os8*ones(1,length(wp)),'c'  );
        wp = m_fixjumps(zpnp(1:181),maxjump);
        plot(wp+os9*ones(1,length(wp)),'c'  )
        plot(wp+os10*ones(1,length(wp)),'c'  )
    end    
end

% Plot coastlines
for i = 1:length(ncst(:,1))
    if ncst(i,1) == NaN
        zceq(i)= NaN + 1j*NaN;
        zcnp(i)= NaN + 1j*NaN;
        zcsp(i)= NaN + 1j*NaN;
    else
        lon = ncst(i,1) + 180 - cent;
        if lon < 0
            lon = lon + 360;
        end
        if lon > 360
            lon = lon - 360;
        end
        [zceq(i),zcnp(i),zcsp(i)] = m_tetra1(lon,ncst(i,2),w1);
    end
end
if mtype == 1
    wceq = m_fixjumps(zceq,maxjump);
    plot(wceq,'k');
end
if mtype == 2 | mtype > 3
    wcsp = m_fixjumps(zcsp,maxjump);
    plot((-1)^mtype*wcsp+os(mtype)*ones(1,length(wcsp)),'k')
end
if mtype >= 3
    wcnp = m_fixjumps(zcnp,maxjump);
    plot(wcnp-os(mtype)*ones(1,length(wcnp)),'k')
end
if mtype == 8
    plot(-wcnp-os8*ones(1,length(wcnp)),'k')
    plot(-wcsp+os8*ones(1,length(wcsp)),'k')
    for j = 1:length(wcsp)
        if real(wcsp(j)) <= 0 
            wcsp(j) = NaN;
        end
    end
    plot(wcsp+os9*ones(1,length(wcsp)),'k' )
    for j = 1:length(wcnp)
        if real(wcnp(j)) >= 0
            wcnp(j) = NaN;
        end
    end
    plot(wcnp+(3*ho2 + 3*wo4*1j)*ones(1,length(wcnp)),'k' )
end

% Plot level curves of linear scale factor
if kplot ~= 0
    for i = 1:length(kfile)
      [zkeq(i),zknp(i),zksp(i)] = m_tetra1(real(kfile(i)),imag((kfile(i))),w1);
    end
    if mtype == 1
        wkeq = m_fixjumps(zkeq,maxjump);
        plot(wkeq,'r');
    end
    if mtype == 2 | mtype > 3 & mtype < 8
        wksp = m_fixjumps(zksp,maxjump);
        plot((-1)^mtype*wksp+os(mtype)*ones(1,length(wksp)),'r')
    end
    if mtype >= 3 & mtype < 8
        wknp = m_fixjumps(zknp,maxjump);
        plot(wknp-os(mtype)*ones(1,length(wknp)),'r')
    end
end

% Draw map boundary
if mtype == 1
    plot([-3*wo4 -3*wo4 5*wo4 5*wo4 -3*wo4],[-ho2 ho2 ho2 -ho2 -ho2],'k')
end
if mtype == 2 | mtype == 3
    plot([-h -h h h -h],[-wo2 wo2 wo2 -wo2 -wo2],'k')
end
if mtype == 4 | mtype == 6
    plot([-3*ho2 -3*ho2 -ho2 -ho2 3*ho2 3*ho2 ho2 ho2 -3*ho2], ...
         [-3*wo4 wo4 wo4 3*wo4 3*wo4 -wo4 -wo4 -3*wo4 -3*wo4],'k')
end
if mtype == 5 | mtype == 7
    plot([-3*ho2 -3*ho2 ho2 ho2 3*ho2 3*ho2 -ho2 -ho2 -3*ho2], ...
         [-wo4 3*wo4 3*wo4 wo4 wo4 -3*wo4 -3*wo4 -wo4 -wo4],'k')
end
end
        