function [Gltl,Gmid,Glar,Gbig,Gtot,Mltl,Mmid,Mlar,Mbig,Mtot] = m_maparea
% finds areas on tetrahedral or Guyou map
% output
% Gltl = area on globe with ksq < 4/3
% Gmid = area on globe with 4/3 < ksq > 2
% Glar = area on globe with 2 < ksq > 4
% Gbig = area on globe with ksq > 4
% Mtot = total area of globe
% Mltl = area on map with ksq < 4/3
% Mmid = area on map with 4/3 < ksq < 2
% Mlar = area on map with 2 < ksq > 4
% Mbig = area on map with ksq > 4
% Mtot = total area of map
% All areas scaled to a globe of unit surface area

Gltl = 0;
Gmid = 0;
Glar = 0;
Gbig = 0;
Gtot = 0;
Mltl = 0;
Mmid = 0;
Mlar = 0;
Mbig = 0;
Mtot = 0; 
r3 = sqrt(3);
for i = 1:100000
    s = 0.00002*(i - 50000);  % sin(latitude)
    for j = 1:100000
        c = cos(0.00001*j*pi);% cos(2*(longitude - north singularity long))
% tetrahedral projection:
%         ksq = 4/sqrt(3*(4*(1+s^2)^2 - (2*r3*s + (1-s^2)*c)^2));
% Guyou projection:      
        ksq  = 4/sqrt((3*(1+s^2)-(1-s^2)*c)^2 - 32*s^2);
        Gtot = Gtot + 1e-10;
        Mtot = Mtot + ksq*1e-10;
        if ksq > 4
            Gbig = Gbig + 1e-10;
            Mbig = Mbig + ksq*1e-10;
        elseif ksq > 2
            Glar = Glar + 1e-10;
            Mlar = Mlar + ksq*1e-10;
        elseif ksq > 4/3    
            Gmid = Gmid + 1e-10;
            Mmid = Mmid + ksq*1e-10;
        else
            Gltl = Gltl + 1e-10;
            Mltl = Mltl + ksq*1e-10;
        end
    end
end